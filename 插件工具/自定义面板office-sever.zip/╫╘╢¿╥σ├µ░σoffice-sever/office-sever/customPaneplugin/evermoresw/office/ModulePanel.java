package evermoresw.office;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import application.Application;
import application.EBeansFactory;
import application.constants.GlobalConstants;
import application.util.Dialogs;
import application.workbooks.Workbook;
import application.workbooks.workbook.documents.Document;
import application.workbooks.workbook.documents.document.section.BaseText;


/**
 * �����ṩ�˼�����office�е��Զ������壬��Ҫ�������ѷ������ϵ�ͼƬ���뵽��ǰ�ĵ���
 * ���ҿ��԰ѵ�ǰ�ĵ��ϴ����������ϣ�Ҳ���Ա��浽���ء�
 */

public class ModulePanel extends JPanel implements ActionListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7085859308696547398L;

	private final int btWidth = 55;

	private final int btHeight = 25;

	private int[] mofValue = new int[]
	{
			1, 2, 3, 4, 5, 10, 15, 16, 17, 18, 19, 20, 70, 80
	};

	private JLabel urlLable, fileLable;

	private JTextField urlField, fileField;

	private JButton downloadBt, saveAsBt, uploadBt;

	/**
	 * 
	 *
	 */
	public ModulePanel()
	{
		fileLable = new JLabel("ͼƬ���֣�");
		fileField = new JTextField();
		urlLable = new JLabel("��������ַ��");
		urlField = new JTextField();
		downloadBt = EBeansFactory.createButton("����");
		downloadBt.addActionListener(this);
		uploadBt = EBeansFactory.createButton("�ϴ�");
		uploadBt.addActionListener(this);
		saveAsBt = EBeansFactory.createButton("����");
		saveAsBt.addActionListener(this);

		add(fileLable);
		add(fileField);
		add(urlLable);
		add(urlField);
		add(downloadBt);
		add(uploadBt);
		add(saveAsBt);

	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Component#doLayout()
	 */
	public void doLayout()
	{
		int x = 5;
		int y = 5;
		fileLable.setBounds(x, y, mofValue[13], mofValue[11]);
		fileField.setBounds(x, 30, mofValue[13], mofValue[11]);
		urlLable.setBounds(x, 30 + mofValue[11], mofValue[13], mofValue[11]+mofValue[5]);
		urlField.setBounds(x, 30 + 2 * mofValue[11]+mofValue[4], 2 * mofValue[12],
				mofValue[11]);
		downloadBt.setBounds(x, 35 + 3 * mofValue[11]+mofValue[4], btWidth, btHeight);
		uploadBt.setBounds(x + btWidth, 35 + 3 * mofValue[11]+mofValue[4], btWidth,
				btHeight);
		saveAsBt.setBounds(x + 2 * btWidth, 35 + 3 * mofValue[11]+mofValue[4], btWidth,
				btHeight);

	}

	/**
	 * 
	 */
	public void actionPerformed(ActionEvent evt)
	{
		Object obj = evt.getSource();
		String urlName = urlField.getText();
		if (obj == downloadBt)
		{
			String fileName = fileField.getText();
			downloadFile(urlName, fileName);
		}
		else if (obj == uploadBt)
		{
			String name = Application.getWorkbooks().getActiveWorkbook()
					.getName();
			if (!"".equals(name))
			{
				unloadFile(urlName, name);
			}
		}
		else if (obj == saveAsBt)
		{
			Dialogs.showSaveDialog(Application.getMainFrame());
		}

	}

	/**
	 * �����û�����ķ�������ַ��ͼƬ���֣��ͷ������������ӣ�ȡ�÷������ϵ��ļ������뵽��ǰ�ĵ���
	 * @param urlName ��������ַ
	 * @param fileName �ļ�����
	 */
	private void downloadFile(String urlName, String fileName)
	{
		java.net.URLConnection con = null;
		try
		{
			java.net.URL url = new java.net.URL(urlName
					+ "servlet/LoadData");
			con = url.openConnection();
			con.setUseCaches(true);
			con.setDoOutput(true);
			con.setDoInput(true);
		}
		catch (Exception ex)
		{
			Dialogs.showMessageDialog("��������ַ����");
			return;
		}
		try
		{
			ByteArrayOutputStream byteout = new ByteArrayOutputStream();
			DataOutputStream out = new DataOutputStream(byteout);
			out.writeUTF(fileName);
			out.flush();

			byte buf[] = byteout.toByteArray();
			con.setRequestProperty("Content-type", "application/octest-stream");
			con.setRequestProperty("Content-length", "" + buf.length);
			DataOutputStream dataout = new DataOutputStream(con
					.getOutputStream());
			dataout.write(buf);
			dataout.flush();
			dataout.close();

			DataInputStream in = new DataInputStream(con.getInputStream());
			File pictureFile = new File("c:\\" + fileName);
			String imagePath = pictureFile.getAbsolutePath();
			FileOutputStream pictureOut = new FileOutputStream(pictureFile);
			byte[] b = new byte[1024];
			int len = 0;
			while ((len = in.read(b)) > 0)
			{
				pictureOut.write(b, 0, len);
			}
			in.close();
			pictureOut.flush();
			pictureOut.close();

			Workbook book = Application.getWorkbooks().getActiveWorkbook();
			if(book!=null)
			{
				int type = Application.getActiveProductType();
				if (type == GlobalConstants.SPREADSHEET)
				{
					book.getWorksheets().getActiveWorksheet().getActiveCell()
							.insertPicture(imagePath);
				}
				else if (type == GlobalConstants.WORDPROCESSOR)
				{
					Document doc = book.getDocuments().getActiveDocument();
					BaseText bastext = doc.getSection(0).getBaseText();
					bastext.insertPicture(doc.getOffset(), imagePath);
				}
				else
				{
					book.getPresentations().getActivePresentation()
							.getActiveSlide().getShapes().addPicture(imagePath);
				}
			}
			pictureFile.delete();

		}
		catch (Exception ex)
		{
			Dialogs.showMessageDialog("��������û�д�ͼƬ��");
		}
		
	}

	/**
	 * �ѵ�ǰ�����ļ�����Ϊ����ļ����ơ�
	 * @param urlName ��������ַ
	 * @param name �ļ���
	 */
	public void unloadFile(String urlName, String name)
	{
		java.net.URLConnection con = null;
		try
		{
			java.net.URL url = new java.net.URL(urlName + "servlet/UpLoadData");
			con = url.openConnection();
			con.setUseCaches(true);
			con.setDoOutput(true);
			con.setDoInput(true);
		}
		catch(Exception ex)
		{
			Dialogs.showMessageDialog("��������ַ����");
			return;
		}
		try
		{
			Workbook book = Application.getWorkbooks().getActiveWorkbook();
			if (book != null)
			{		 
				byte[] bytes = Application.getWorkbooks().getWorkbookAsByteArray(book);					
				con.setRequestProperty("Content-type",
						"application/octest-stream");
				con.setRequestProperty("Content-length", "" + bytes.length);		
				DataOutputStream bytesOut = new DataOutputStream(con.getOutputStream());
				bytesOut.writeUTF(name);
				bytesOut.write(bytes);
				bytesOut.flush();
				bytesOut.close();
				
				con.getInputStream();
			}
			Application.getWorkbooks().closeAll();
		}
		catch (Exception ex)
		{
			Dialogs.showMessageDialog("���浽����������");
			return;
		}

	}

}
