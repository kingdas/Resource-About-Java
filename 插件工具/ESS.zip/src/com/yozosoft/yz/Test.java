package com.yozosoft.yz;


import application.AppParameters;
import application.Application;
import application.ApplicationFactory;
import application.IApplication;
import application.Workbooks;
import application.constants.GlobalConstants;


public class Test
{
	
	public static void main(String[] args)
	{
//		Application.getApplicationInstance();
		//ֱ�Ӵ򿪵��ӱ���
		AppParameters appParameters = AppParameters.getInstance();
		IApplication application = ApplicationFactory.createInstance(appParameters);
		Workbooks workbooks = application.getWorkbooks();
		workbooks.addWorkbook(GlobalConstants.SPREADSHEET);
//		Application.getApplicationInstance();
	}

	public Test()
	{
		// TODO Auto-generated constructor stub
	}

}
